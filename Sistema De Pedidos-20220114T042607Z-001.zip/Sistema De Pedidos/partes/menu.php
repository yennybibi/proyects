<nav>
<a href="principal.php?da=1">Platos de la carta </a>
<a href="mesa.php?da=1">Mesas </a>
<a href="pedido.php?da=1">Pedidos </a>
<a href="usuario.php?da=1">Usuarios </a>
</nav>
<br><br>

