<?php 

require_once('partes/head.php');


<section>Mesas</section>

CRUD
C = Create -> select
R = Read -> insert
U = update -> update
D = delete -> delete


?>